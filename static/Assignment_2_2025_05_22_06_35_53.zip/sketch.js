let spores = [];
let maxSpores = 100;
let audioCtx;
let masterGain;

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(10);
  noFill();
  spores.push(new Spore(random(width), random(height), 10)); // Start with initial spore size of 10
  
  // sound
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  masterGain = audioCtx.createGain();
  masterGain.connect(audioCtx.destination);
  masterGain.gain.value = 0.05; // Volume control
  //userStartAudio(); // p5.js helper to resume audio context on first interaction
}

function draw() {
  background(10, 10);

  let speedFactor = map(mouseX, 0, width, 0.5, 2);
  
  let volume = map(mouseY, height, 0, 0.01, 1); // Inverted so top = loud, bottom = quiet
masterGain.gain.value = constrain(volume, 0.01, 1);

  for (let i = spores.length - 1; i >= 0; i--) {
    spores[i].update(speedFactor);
    spores[i].display();
    if (spores[i].lifespan <= 0) {
      spores.splice(i, 1);
    }
  }

  // draw mycelial lines
  stroke(100, 50);
  for (let i = 0; i < spores.length; i++) {
    for (let j = i + 1; j < spores.length; j++) {
      let d = dist(spores[i].x, spores[i].y, spores[j].x, spores[j].y);
      if (d < 100) {
        line(spores[i].x, spores[i].y, spores[j].x, spores[j].y);
      }
    }
  }
}

class Spore {
  constructor(x, y, r) {
    this.x = x;
    this.y = y;
    this.r = r;  // Radius stays as it is
    this.vx = random(-2, 2);
    this.vy = random(-2, 2);
    this.lifespan = 500; // Increased lifespan
  }

  update(speedFactor) {
  this.x += this.vx * speedFactor;
  this.y += this.vy * speedFactor;
  this.lifespan -= 1;

  let bounced = false;

  if (this.x < 0) {
    this.x = 0;
    this.vx *= -1;
    bounced = true;
  } else if (this.x > width) {
    this.x = width;
    this.vx *= -1;
    bounced = true;
  }

  if (this.y < 0) {
    this.y = 0;
    this.vy *= -1;
    bounced = true;
  } else if (this.y > height) {
    this.y = height;
    this.vy *= -1;
    bounced = true;
  }

  if (bounced) {
    playSporeSound(this.x, this.y, this.r); // ← sound on bounce
    this.branch(); // ← still branches like before
  }
}


  display() {
    stroke(255, this.lifespan);  // Fade out based on lifespan
    ellipse(this.x, this.y, this.r * 2);  // No size reduction
  }

  branch() {
  if (spores.length < maxSpores) {
    spores.push(new Spore(this.x, this.y, this.r * 0.9));
    playSporeSound(this.x, this.y, this.r);
  }
  }
}

function playSporeSound(x, y) {
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  const panNode = audioCtx.createStereoPanner();

  // Map x to frequency and y to stereo pan
  let freq = map(x, 0, width, 100, 800);
  let pan = map(y, 0, height, -1, 1);

  osc.type = "sine";
  osc.frequency.setValueAtTime(freq, audioCtx.currentTime);

  gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.2);

  panNode.pan.value = pan;

  osc.connect(gain);
  gain.connect(panNode);
  panNode.connect(masterGain);

  osc.start();
  osc.stop(audioCtx.currentTime + 0.2);
}
function mousePressed() {
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
}


/*
  This sketch explores fungal being through interaction:
  - Spores (circles) move and bounce.
  - When a spore hits a wall, it splits into a smaller spore, now reduced by 10%.
  - Spores connect with faint lines when close, forming a mycelial network.
  - MouseX changes the speed, letting you speed up or slow fungal activity.
  - Spores now fade out and die over time, suggesting impermanence and decay.
  Inspired by Merlin Sheldrake's essay, it visualises the relational, branching
  life of fungi through recursion, complexity, decay, and soft interaction.
*/